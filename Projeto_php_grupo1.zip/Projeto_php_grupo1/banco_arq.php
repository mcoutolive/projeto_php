<?php

$bdServidor = 'localhost';
// Pode colocar o próprio IP da máquina na variável servidor
$bdUsuario = 'sistematarefa';
$bdSenha = 'sistema';
$bdBanco = 'projeto_php';
$conexao = mysqli_connect($bdServidor, $bdUsuario, $bdSenha, $bdBanco);

if (!$conexao){
    echo "Problemas para conectar no banco. Erro: ";
    echo mysqli_connect_error();
    die();
}

function buscar_clientes($conexao)
{
    $sqlBusca = 'SELECT * FROM clientes';
    $resultado = mysqli_query($conexao, $sqlBusca);
    $clientes = [];
    while ($clientes = mysqli_fetch_assoc($resultado)){
        $clienets[] = $clientes;
    }
    return $clientes;

}

function gravar_cliente($conexao, $clientes)
{
    $sqlGravar = "
                INSERT INTO clientes 
                 (CPF_CNPJ, Clientes_nome, Clientes_email, Eh_pessoa_fisica, Clientes_telefone, Clientes_endereco, Tipo_solicitacao) 
                 VALUES 
                 (
                 '{$clientes['CPF_CNPJ']}',
                 '{$clientes['Clientes_nome']}',
                 '{$clientes['Clientes_email']}',
                 '{$clientes['Eh_pessoa_fisica']}'
                 '{$clientes['Clientes_telefone']}'
                 '{$clientes['Clientes_endereco']}'
                 '{$clientes['Tipo_solicitacao']}'
                 )
    ";

    mysqli_query($conexao, $sqlGravar);             
}

?>
